﻿using Fulbi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Fulbi.Controllers
{
    public class TorneosController : Controller
    {
        private readonly FulbiContext _context;

        public TorneosController(FulbiContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Torneos.ToListAsync());
        }
    }
}
