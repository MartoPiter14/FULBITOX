﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Usuario
    {
        public Usuario()
        {
            Torneos = new HashSet<Torneo>();
        }

        public int IdUsuario { get; set; }
        public string Nombre { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;

        public virtual ICollection<Torneo> Torneos { get; set; }
    }
}
