﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Torneo
    {
        public Torneo()
        {
            Equipos = new HashSet<Equipo>();
            Fechas = new HashSet<Fecha>();
        }

        public int IdTorneo { get; set; }
        public string Nombre { get; set; } = null!;
        public int CantidadEquipos { get; set; }
        public int CantidadFechas { get; set; }
        public int IdUsuario { get; set; }
        public int IdTipoTorneo { get; set; }

        public virtual TipoTorneo IdTipoTorneoNavigation { get; set; } = null!;
        public virtual Usuario IdUsuarioNavigation { get; set; } = null!;
        public virtual ICollection<Equipo> Equipos { get; set; }
        public virtual ICollection<Fecha> Fechas { get; set; }
    }
}
