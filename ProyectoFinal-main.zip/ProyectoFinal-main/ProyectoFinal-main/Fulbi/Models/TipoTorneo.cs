﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class TipoTorneo
    {
        public TipoTorneo()
        {
            Torneos = new HashSet<Torneo>();
        }

        public int IdTipoTorneo { get; set; }
        public string Modalidad { get; set; } = null!;

        public virtual ICollection<Torneo> Torneos { get; set; }
    }
}
