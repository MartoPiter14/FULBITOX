﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Partido
    {
        public int Id { get; set; }
        public int? IdEquipo01 { get; set; }
        public int? IdEquipo02 { get; set; }
        public DateTime? Fecha { get; set; }
        public int? IdFecha { get; set; }
        public int? Goles01 { get; set; }
        public int? Goles02 { get; set; }

        public virtual Equipo? IdEquipo01Navigation { get; set; }
        public virtual Equipo? IdEquipo02Navigation { get; set; }
        public virtual Fecha? IdFechaNavigation { get; set; }
    }
}
